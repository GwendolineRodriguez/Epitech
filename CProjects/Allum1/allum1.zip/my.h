/*
** my.h for my in /home/rodrig_1/rendu/Prgelm/Allum1
**
** Made by gwendoline rodriguez
** Login   <rodrig_1@epitech.net>
**
** Started on  Sat Feb 21 19:24:01 2015 gwendoline rodriguez
** Last update Sun Feb 22 17:56:37 2015 gwendoline rodriguez
*/

#ifndef MY_H_
# define MY_H_

int     *matchs(int *tab, char *buffer, int i);
int     lines(int *tab, char *buffer);
int	*game(int *tab, char *buffer);
int	*my_pyramid(int *tab, int c);
int	*ia(int *tab);

#endif /*MY_H_*/

