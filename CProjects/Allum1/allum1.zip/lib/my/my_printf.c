/*
** my_printf.c for my_printf in /home/rodrig_1/lib/my
**
** Made by gwendoline rodriguez
** Login   <rodrig_1@epitech.net>
**
** Started on  Wed Nov 12 09:36:51 2014 gwendoline rodriguez
** Last update Tue Nov 18 17:53:15 2014 gwendoline rodriguez
*/

#include <stdarg.h>

int     my_printf(char *format, ...)
{
}
