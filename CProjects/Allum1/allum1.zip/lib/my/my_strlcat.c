/*
** my_strlcat.c for my_strlcat in /home/rodrig_1/lib/my
**
** Made by gwendoline rodriguez
** Login   <rodrig_1@epitech.net>
**
** Started on  Tue Nov 18 18:45:28 2014 gwendoline rodriguez
** Last update Tue Nov 18 18:45:29 2014 gwendoline rodriguez
*/

int	my_strlcat(char *dest, char *src, int size)
{
}
