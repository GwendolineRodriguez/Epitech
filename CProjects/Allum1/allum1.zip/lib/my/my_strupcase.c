/*
** my_strupcase.c for my_strupcase in /home/rodrig_1/lib/my
**
** Made by gwendoline rodriguez
** Login   <rodrig_1@epitech.net>
**
** Started on  Tue Nov 18 18:46:33 2014 gwendoline rodriguez
** Last update Tue Nov 18 18:46:42 2014 gwendoline rodriguez
*/

char     *my_strupcase(char *str)
{
  int	i;

  i = 0;
  while (str[i])
    {
      if (str[i] >= 'a' && str[i] <= 'z')
	str[i] = str[i] - 32;
      i = i + 1;
    }
  return (str);
}
