/*
** my_str_to_wordtab.c for my_str_to_wordtab.c in /home/rodrig_1/lib/my
**
** Made by gwendoline rodriguez
** Login   <rodrig_1@epitech.net>
**
** Started on  Tue Nov 18 18:17:56 2014 gwendoline rodriguez
** Last update Thu Nov 27 00:19:17 2014 gwendoline rodriguez
*/

#include <stdlib.h>

int	my_count_word(char *str)
{
  int	i;
  int	cpt;

  i = 0;
  cpt = 0;
  while (str[i])
    {
      if ((str[i] >= 'a' && str[i] <= 'z') || (str[i] >= 'A' && str[i] <= 'Z')
	  || (str[i] >= '0' && str[i] <= '9'))
	{
	  cpt = cpt + 1;
	  while (str[i] && ((str[i] >= 'a' && str[i] <= 'z')
			    || (str[i] >= 'A' && str[i] <= 'Z')
			    || (str[i] >= '0' && str[i] <= '9')))
	    i = i + 1;
	}
      i = i + 1;
    }
  return (cpt);
}

char	**my_str_to_wordtab(char *str)
{
  int	i;
  int	j;
  int	n;
  int	word;
  char	**tab;

  i = 0;
  j = 0;
  n = 0;
  word = my_count_word(str);
  tab = malloc(sizeof(char *) * (word + 1));
  while (str[i] != '\0')
    {
      tab[n] = malloc(sizeof(char) * my_strlen(str));
      if ((str[i] <= '/' && str[i] >= 32) || (str[i] <= '@' && str[i] >= ':' ) ||
	  (str[i] <= '`' && str[i] >= '[') || (str[i] <= 127 && str[i] >= '{'))
	i++;
      j = 0;
      while ((str[i] >= 48 && str[i] <= 57) || (str[i] >= 65 && str[i] <= 90)
	     || (str[i] >= 97 && str[i] <= 122))
	{
	  tab[n][j] = str[i];
	  i++;
	  j++;
	}
      n++;
    }
  tab[n] = NULL;
  return (tab);
}
