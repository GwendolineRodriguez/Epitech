/*
** get_next_line.c for get_next_line in /home/rodrig_1/lib/my
**
** Made by gwendoline rodriguez
** Login   <rodrig_1@epitech.net>
**
** Started on  Tue Nov 18 23:18:02 2014 gwendoline rodriguez
** Last update Thu Jan 15 15:40:48 2015 gwendoline rodriguez
*/

#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include "get_next_line.h"

int             my_strlen(char *str)
{
  int           i;

  i = 0;
  while (str[i] != '\0')
    i = i + 1;
  return (i);
}

char            *my_realloc(char *src, int size)
{
  int           i;
  char          *dest;

  i = 0;
  if ((src = malloc(sizeof(*dest) * (my_strlen(src) + size))) == NULL)
    return (NULL);
  while (src[i])
    {
      src[i] = dest[i];
      i = i + 1;
    }
  free(src);
  return (dest);
}

char            *get_next_line(const int fd)
{
  static char   buffer[BUFF_MAX];
  static int    ret = 0;
  static char   *out_put = NULL;
  static int    cpt = 0;
  static int    i;

  i = 0;
  out_put = malloc(sizeof(char *)*BUFF_MAX + 1);
  ret = read(fd, buffer, BUFF_MAX);
  if (ret < 0)
    return (NULL);
  while (buffer[cpt] != '\n' && buffer[cpt + 1] != '\0')
    {
      out_put[i] = buffer[cpt];
      cpt = cpt + 1;
      i = i + 1;
    }
  if (buffer[cpt] == '\0')
    return (NULL);
  cpt = cpt + 1;
  out_put[i] = '\0';
  return (out_put);
}
