/*
** my_showstr.c for my_showstr in /home/rodrig_1/lib/my
**
** Made by gwendoline rodriguez
** Login   <rodrig_1@epitech.net>
**
** Started on  Tue Nov 18 18:39:54 2014 gwendoline rodriguez
** Last update Tue Nov 18 18:39:55 2014 gwendoline rodriguez
*/

int	my_showstr(char *str)
{
}
