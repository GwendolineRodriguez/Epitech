/*
** my_putchar.c for my_putchar in /home/rodrig_1/lib/my
**
** Made by gwendoline rodriguez
** Login   <rodrig_1@epitech.net>
**
** Started on  Tue Nov 18 18:37:30 2014 gwendoline rodriguez
** Last update Tue Nov 18 18:37:37 2014 gwendoline rodriguez
*/

int	my_putchar(char c)
{
  write(1, &c, 1);
  return (0);
}
