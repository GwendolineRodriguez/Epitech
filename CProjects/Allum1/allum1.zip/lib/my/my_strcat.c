/*
** my_strcat.c for my_strcat in /home/rodrig_1/lib/my
**
** Made by gwendoline rodriguez
** Login   <rodrig_1@epitech.net>
**
** Started on  Tue Nov 18 18:41:29 2014 gwendoline rodriguez
** Last update Tue Nov 18 18:41:32 2014 gwendoline rodriguez
*/

char	*my_strcat(char *dest, char *src)
{
  int   i;
  int   j;

  i = 0;
  j = 0;
  while (dest[i] != '\0')
    {
      i = i + 1;
    }

  while (src[j] != '\0')
    {
      dest[i] = src[j];
      j = j + 1;
    }
  dest[i] = '\0';
  return (dest);
}
