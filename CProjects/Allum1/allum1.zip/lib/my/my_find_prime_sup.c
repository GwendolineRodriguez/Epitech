/*
** my_find_prime_sup.c for my_find_prime_sup in /home/rodrig_1/lib/my
**
** Made by gwendoline rodriguez
** Login   <rodrig_1@epitech.net>
**
** Started on  Tue Nov 18 18:35:00 2014 gwendoline rodriguez
** Last update Tue Nov 18 18:35:01 2014 gwendoline rodriguez
*/

int	my_find_prime_sup(int nb)
{
}
