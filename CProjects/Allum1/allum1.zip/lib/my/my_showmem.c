/*
** my_showmem.c for my_showmem in /home/rodrig_1/lib/my
**
** Made by gwendoline rodriguez
** Login   <rodrig_1@epitech.net>
**
** Started on  Tue Nov 18 18:39:21 2014 gwendoline rodriguez
** Last update Tue Nov 18 18:39:22 2014 gwendoline rodriguez
*/

int	my_showmem(char *str, int size)
{
}
