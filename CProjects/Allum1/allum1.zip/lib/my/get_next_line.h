/*
** get_next_line.h for get_next_line in /home/rodrig_1/rendu/CPE_2014_get_next_line
**
** Made by gwendoline rodriguez
** Login   <rodrig_1@epitech.net>
**
** Started on  Wed Nov 12 16:51:31 2014 gwendoline rodriguez
** Last update Thu Nov 20 16:48:11 2014 gwendoline rodriguez
*/

#ifndef GET_NEXT_LINE_H_
# define GET_NEXT_LINE_H_

#define BUFF_MAX 4096

char    *get_next_line(const int fd) ;

#endif /* !GET_NEXT_LINE_H_ */
