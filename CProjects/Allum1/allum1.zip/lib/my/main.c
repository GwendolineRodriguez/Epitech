/*
** main.c for main in /home/rodrig_1/lib/my
**
** Made by gwendoline rodriguez
** Login   <rodrig_1@epitech.net>
**
** Started on  Mon Dec  1 18:11:06 2014 gwendoline rodriguez
** Last update Mon Dec  1 18:29:17 2014 gwendoline rodriguez
*/

int		main()
{
  struct s_list	*list;

  list = NULL;
  my_put_in_list(&list, "toto", 42);
  my_put_in_list(&list, "titi", 24);
  return (0);
}
