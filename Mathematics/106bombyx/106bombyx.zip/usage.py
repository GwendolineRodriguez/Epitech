#!/usr/bin/python
# -*- coding: utf-8 -*-
## usage.py for usage in /home/rodrig_1/rendu/Maths/103architecte
##
## Made by gwendoline rodriguez
## Login   <rodrig_1@epitech.net>
##
## Started on  Sun Dec  7 16:31:56 2014 gwendoline rodriguez
## Last update Sun Feb 22 18:32:16 2015 gwendoline rodriguez
##

print "Usage: ./106bombyx k(integer >= 1 and <= 4)."
